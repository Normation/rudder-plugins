ChangeLog
=========

1.1.2 (2016-07-28)
------------------
-  Added parameter **chunk\_size** for object **ZabbixSender**
