.. _pyzabbix.api:

===================
Module `pyzabbix.api`
===================

This module provide classes to work with Zabbix API.

.. automodule:: pyzabbix.api
    :members:
    :exclude-members: ZabbixAPIException, ZabbixAPIObjectClass
